package jcifs.util.transport;

public interface Request {
}
